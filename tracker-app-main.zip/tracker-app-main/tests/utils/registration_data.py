registration_data_happy_0 = {
    "username": "dangerzone",
    "first_name": "Lana",
    "middle_name": "",
    "last_name": "Kane",
    "date_of_birth": "1985-03-15",
    "email": "lanakane@example.com",
    "location": "New York",
    "password": "password123",
    "confirm_password": "password123",
}

registration_data_happy_1 = {
    "username": "duchess",
    "first_name": "Sterling",
    "middle_name": "",
    "last_name": "Archer",
    "date_of_birth": "1978-04-01",
    "email": "worlds-most-famous-spy@example.com",
    "location": "New York",
    "password": "password123",
    "confirm_password": "password123",
}

registration_data_happy_2 = {
    "username": "carol",
    "first_name": "Cheryl",
    "middle_name": "",
    "last_name": "Tunt",
    "date_of_birth": "1982-09-22",
    "email": "caroltunt@example.com",
    "location": "New York",
    "password": "password123",
    "confirm_password": "password123",
}

registration_data_sad_0 = {
    "username": "pam",
    "first_name": "Pam",
    "middle_name": "",
    "last_name": "Poovey",
    "date_of_birth": "",  # Invalid: Date of birth is missing
    "email": "pampoovey@example.com",
    "location": "New York",
    "password": "password123",
    "confirm_password": "password456",  # Invalid: Confirm password doesn't match password
}
